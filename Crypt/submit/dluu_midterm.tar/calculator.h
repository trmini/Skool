#include "Poly.h"

void calculator(Poly& f, Poly& g, Big_int& n, Poly& result);
