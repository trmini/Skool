import java.lang.*;
import java.net.*;

/**
*   Computer Network - CS4873
*   Term Project - Fall 2001
*   Implementation of reliable network transport scheme based on UDP
*   Dien Trang Luu
**/

public class mySocket extends DatagramSocket, DatagramPacket {
    
    protected int myPortNum = 0;
    protected int otherPortNum = 0;
    protected InetAddress myInetAddress;
    protected InetAddress otherInetAddress;
    protected int mySeq = 0;
    protected int offsetSeq;
    protected Random random = new Random();
    protected int RANDOM_RANGE = 1000;
    
    protected int myPacketSize = 512; /* Size for each packet, default 512 bytes */
    
    
    DatagramSocket myDatagramSocket;
    DatagramPacket [] myDatagramPackets;
    
    public mySocket() {
      offsetSeq = random.nextInt(RANDOM_RANGE);
      myDatagramSocket = new DatagramSocket();
    }
    
    public mySocket(int portNum) {
      offsetSeq = random.nextInt(RANDOM_RANGE);
      myPortNum = portNum;
      myHostName = null;
      myDatagramSocket = new DatagramSocket(portNum);
    }
    
    public mySocket(int portNum,  InetAddress hostAddress) {
      offsetSeq = random.nextInt(RANDOM_RANGE);
      myPortNum = portNum;
      myInetAddress = hostAddress;
      myDatagramSocket = new DatagramSocket(portNum, myInetAddress);
    }
      

    /* Method Implementation */
    public void close () {
      
    public boolean connect(InetAddress hostAddress, int portNum) {
    /**
    *  OK my port is portNum, want to connect;
    **/
      InetAddress serverAddress;
      int serverPort;
      /* Construct init packet */
      /* Wait for reply from server */

      otherInetAddress = serverAddress;
      otherPortNum = serverPort;
      return true;
    }
    public accept(int portNum) {
    /**
    *  OK I know your port, here is my port,  feel free to use it
    **/
    
    }
    public InputStream getInputStream() {
    /* Handling file descriptor to read from sender */
    
    }
    public OutputStream getOutputStream() {
    /* Handling file descriptor to write to receiver */
    
    }

    private int receive(byte [] buf) {
    }
    
    private int send(byte [] buf, int length) {
      int window_sz = 10;
      int window_pkt = window_sz;
      int index = 0;
      int max_index = length/myPacketSize;
      for (index = 0; index < max_index; index++) {
      /* Attention: Construction of packets without header, sequence num needed, acked needed */
        myDatagramPackets[index] = new DatagramPacket(buf[index*myPacketSize], myPacketSize, otherInetAddress, otherPortNum);
      }
      if ((index-1)*myPacketSize < buf.length()) {
      /* Attention: Construction of the last packet */
        myDatagramPackets[index] = new DatagramPacket(buf[index*myPacketSize], (buf.length() - (index*myPacketSize)), otherInetAddress, otherPortNum);
      }
      index = 0;
      while (index <= max_index) {
        window_pkt = index + window_sz;
        while (index < window_pkt) {
          myDatagramSocket.send(myDatagramPackets[index]);
	  index++;
        }
	/*Waiting for NACK */
        byte temp[myPacketSize];
        DatagramPacket nackPacket = new DatagramPacket(temp, temp.length());
	/* Install NACK timer here */
        Thread ackTimer;
	
        if ((int) temp[0] <= window_pkt) {
	  index = (int) temp[0];
	  window_pkt = index + window_sz; /* Slide sending window */
	  continue;
	}
	else {
	  break;
	}
      }
    }
    
    public void close() {
      /* Do smth to handle close section */
      
      myDatagramSocket.close();
    }
  }
